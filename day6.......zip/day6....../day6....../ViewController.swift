//
//  ViewController.swift
//  day6......
//
//  Created by MacStudent on 2018-02-27.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var btnStart: UIButton!
    
    @IBOutlet weak var btnStop: UIButton!
    
    @IBOutlet weak var moodsSegment: UISegmentedControl!
    
    @IBOutlet weak var lblStepperValue: UIStepper!
    
    @IBOutlet weak var Slider: UISlider!
    
    @IBOutlet weak var ProgressView: UIProgressView!
    
    @IBOutlet var ActivityIndicator: UIView!
    @IBOutlet weak var imgMood: UIImageView!
    var moodImages: [UIImage] = [
        UIImage(named: "happy.jpeg")!,
         UIImage(named: "angry.jpeg")!,
         UIImage(named: "sad.jpeg")!,
         
    ]
    var progressTimer = Timer()
    
   
    @IBAction func btnStartAction(_ sender: UISegmentedControl) {
    }
    
        
    activityIndicator.startAnimating()
        
    }
    
    

         activityIndicator.stopAnimating()    }
    super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

