//
//  ViewController.swift
//  day6
//
//  Created by MacStudent on 2018-02-27.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txtCarColor: UITextField!
    
    @IBAction func btnAddNewAction(_ sender: UIButton) {
        self.writeProperty.List()
        
    }
    
    @IBAction func btnListAllAction(_ sender: Any) {
    }
}
    @IBOutlet weak var txtCarPlate: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    


func writePropertyList(){
    let mycar = NSMutabledictionary()
    myCar["CarPlate"] = self. txtCarPlate.text
    myCar["CarColor"] = self.txtCarColor.text
    if let plistPath = Bundle.main.path(forResource: "Cars", ofType: "plist")
    {
        let carsplist = NSMutableArray(contentsOffile: plistpath)
        carsplist?.add(mycar)
        if(carsplist?.write(toFile: plistspath, atomically: true))! {
            print("carslist : \(string(describing: carsplist))")
        }
    }else{
        print("Unable to locate plist file")
    }
    
}
}
